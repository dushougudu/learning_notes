from scrapy.loader import ItemLoader
from scrapy.loader.processors import TakeFirst, MapCompose, Join


class LinkLoader(ItemLoader):

    def replace(x):
        x = x.replace(' ', '')
        return x.replace("\n", "")

    default_output_processor = TakeFirst()

    title_in = MapCompose(replace)
